/**
 * @file
 * Global utilities.
 *
 */
(function (Drupal) {

  'use strict';

  Drupal.behaviors.latest_site = {
    attach: function (context, settings) {

    }
  };

})(Drupal);
;
